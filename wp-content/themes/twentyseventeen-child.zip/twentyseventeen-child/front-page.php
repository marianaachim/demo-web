<?php
/*
 Template Name: Homepage
 */

 get_header();?>

<div id="homepage" class="content-area">
        <?php echo do_shortcode("[resources-list-shortcode]"); ?>

     
</div>

